indexperm <-
function(a,b=NULL){
    if (class(a)=="numeric"){a<-1:a}
    if (class(b)=="numeric"){b<-1:b}
    if (is.null(b)){
        sepstr=""
        indexperm<-paste(a[1],sep=sepstr)
    }else{
        sepstr=","
        indexperm<-paste(a[1],b,sep=sepstr)
    }
    for (i in 2:length(a)){
        indexperm<-c(indexperm,paste(a[i],b,sep=sepstr))
    }
    indexperm
}
