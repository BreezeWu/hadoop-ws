forward <-
function(m,forwardv){
    for (j in 1:ncol(m)){
        m[,j]<-m[,j]*forwardv[j]
    }
    m
}
