ent <-
function(m){
    -apply(m*log(m),2,sum)/log(nrow(m))
}
