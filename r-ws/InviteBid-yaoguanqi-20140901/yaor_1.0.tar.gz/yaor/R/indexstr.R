indexstr <-
function(obj){
    if ((is.array(obj)|is.matrix(obj))){
        if (length(attr(obj,"dim"))>=2){
            indexstr<-indexperm(as.numeric(attr(obj,"dim")[1]))
            for (i in as.numeric(attr(obj,"dim")[-1])){
                indexstr<-indexperm(indexstr,i)
            }
        }else{indexstr<-1:length(obj)}
    }else{indexstr<-1:length(obj)}
    indexstr
}
