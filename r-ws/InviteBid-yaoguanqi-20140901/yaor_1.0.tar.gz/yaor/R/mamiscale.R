mamiscale <-
function(v,scale){if (max(v)==min(v)){v-v+scale[1]}else{(v-min(v))/(max(v)-min(v))*(scale[2]-scale[1])+scale[1]}}
