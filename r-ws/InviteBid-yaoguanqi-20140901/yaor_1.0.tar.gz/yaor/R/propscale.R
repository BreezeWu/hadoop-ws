propscale <-
function(v,divider){if (divider=="sum"){v/sum(v)}else if (divider=="max"){v/max(v)}}
