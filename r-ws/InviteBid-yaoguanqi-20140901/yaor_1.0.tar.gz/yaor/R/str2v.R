str2v <-
function(x,strsplit=" "){unlist(strsplit(x,strsplit))}
