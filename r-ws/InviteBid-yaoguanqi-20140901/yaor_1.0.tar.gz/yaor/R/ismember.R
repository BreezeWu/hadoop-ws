ismember <-
function(obj,objective){
    for(i in 1:length(indexstr(obj))){
        if(eval(parse(text=paste("any(objective==obj[",indexstr(obj)[i],"])",sep="")))){
            eval(parse(text=paste("obj[",indexstr(obj)[i],"]=1",sep="")))
        }else{
            eval(parse(text=paste("obj[",indexstr(obj)[i],"]=0",sep="")))
        }
    }
    as.logical(as.numeric(obj))
}
