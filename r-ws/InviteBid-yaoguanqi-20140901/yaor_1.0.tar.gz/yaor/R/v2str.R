v2str <-
function(x,collapse=" "){paste(x,collapse=collapse)}
