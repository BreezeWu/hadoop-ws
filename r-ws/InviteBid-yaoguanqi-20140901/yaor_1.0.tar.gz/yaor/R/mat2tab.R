mat2tab <-
function(m,in1row,rownames){
    if (rownames){
        strtab<-"\n\r| |"
        sepline<-paste("|",v2str(rep("-|",times=ncol(m)+1),collapse=""),sep="")
    }else{
        strtab<-"\n\r|"
        sepline<-paste("|",v2str(rep("-|",times=ncol(m)),collapse=""),sep="")
    }
    
    if (in1row) {
        initrow<-2
        for (j in 1:ncol(m)){
            strtab<-paste(strtab,m[1,j],"|",sep="")
        }
    } else {
        initrow<-1
        for (j in 1:ncol(m)){
            strtab<-paste(strtab,colnames(m)[j],"|",sep="")
        }
    }
    strtab<-paste(strtab,"\n",sepline,sep="")
    
    for (i in initrow:nrow(m)){
        if (rownames){
            strtab<-paste(strtab,"\n","|",rownames(m)[i],"|",sep="")
        } else {
            strtab<-paste(strtab,"\n","|",sep="")
        }
        for (j in 1:ncol(m)){  
            strtab<-paste(strtab,m[i,j],"|",sep="")   
        }
    }
    paste(strtab,"\n\r",sep="")
}
