weight <-
function(dataent,forwardv){
    #正向化
    dataent<-forward(dataent,forwardv)
    datascale<-apply(dataent,2,mamiscale,scale=c(1,2))
    datapropotion<-apply(datascale,2,propscale,divider="sum")
    ent<-ent(datapropotion)#熵值
    #ent<--apply(datascale*log(datascale),2,sum)/log(nrow(datascale))
    difratio<-(1-ent)/(length(ent)-sum(ent))#差异系数
    #difrati<-1-ent
    w=difratio/sum(difratio)#权重
    matw<-matrix(w,1)
    colnames(matw)<-names(w)
    matw
}
