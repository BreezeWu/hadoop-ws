
old-conf-files目录下的文件并非实时更新, 最后日期应该是2014年7月18日.
conf-files下的文件是实时更新的(ln -s链接到当github工程hadoop-ws)
