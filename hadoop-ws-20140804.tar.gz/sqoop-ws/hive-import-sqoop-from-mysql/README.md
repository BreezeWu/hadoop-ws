利用sqoop-1.4.4,从mysql导出数据到hadoop-2.2.0的hive中(而hive又使用了mysql)

数据源: master-hadoop主机上的dm2014
目标: master-hadoop上的hdfs和hive


