数据与预处理不区分单双月,数据分析时使用相应单双月查询语句

userinfo-preprocess-onebigdata/	所有数据在一张大笔中
old.userinfo-preprocess-m1m2/	原来预处理区分单双月的脚本

===================
参考:
1. 数据分析	~/workspace_github/hadoop-ws/spark-ws/MLlib/userinfo-mining/
