这是mapreduce-ws的README.md
