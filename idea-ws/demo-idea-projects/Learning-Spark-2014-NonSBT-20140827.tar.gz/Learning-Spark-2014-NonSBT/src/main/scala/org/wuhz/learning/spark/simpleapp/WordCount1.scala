package org.wuhz.learning.spark.simpleapp

/**
 * Created by hadoop on 8/27/14.
 */
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.SparkContext._

object WordCount1 {
  def main(args: Array[String]) {
    if (args.length == 0) {
      System.err.println("Usage: WordCount1 <file1>")
      System.exit(1)
    }

    val conf = new SparkConf().setAppName("WordCount1")
    val sc = new SparkContext(conf)
    sc.textFile(args(0)).flatMap(_.split(" ")).map(x => (x, 1)).reduceByKey(_ + _).take(10).foreach(println)
    sc.stop()
  }
}

/*
input:  input/words-data/* 或者 hdfs://master-hadoop:9000/user/hadoop/input/words-data/*
export input_data=hdfs://master-hadoop:9000/user/hadoop/input/words-data/*
./bin/spark-submit --master local --class org.wuhz.learning.spark.simpleapp.WordCount1 --executor-memory 500m Learning-Spark-2014-NonSBT.jar ${input_data}
 */