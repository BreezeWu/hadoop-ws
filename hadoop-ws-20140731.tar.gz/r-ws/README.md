# -----------------------------------------------------------------------------
# 目录说明
# -----------------------------------------------------------------------------

# result-data 来自spark-ws/MLlib/result-data
# 创建ln的语句为
ln -s ~/workspace_github/hadoop-ws/spark-ws/MLlib/result-data ~/workspace_github/hadoop-ws/r-ws/result-data
