mvn archetype:generate -DgroupId=org.wuhz.maven -DartifactId=helloworld -Dpackage=org.wuhz.maven -Dversion=0.1-SNAPSHOT
