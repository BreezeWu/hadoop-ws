hadoop-ws, 大数据分析相关技术的个人工作目录
=========

hadoop learning and developing code.

目录结构: {类型}-ws
hadoop-ecosystem-conf	:hadoop生态系统中,各个应用的配置文件
scala-ws		scala
spark-ws		spark
mahout-ws		mahout
mapreduce-ws		mapreduce算法框架相关的内容
yarn-ws			yarn资源管理相关的内容
linux-ws		linux操作系统相关内容

...以此类推...

=========
git学习的好地方:
(1) Pro Git
	http://git-scm.com/book 
(2) Git教程: 多人协作
	http://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000/0013760174128707b935b0be6fc4fc6ace66c4f15618f8d000 
(3) 起步-初次运行-Git-前的配置 (" http://git-scm.com/book/zh/起步-初次运行-Git-前的配置 ")
	http://git-scm.com/book/zh/%E8%B5%B7%E6%AD%A5-%E5%88%9D%E6%AC%A1%E8%BF%90%E8%A1%8C-Git-%E5%89%8D%E7%9A%84%E9%85%8D%E7%BD%AE



