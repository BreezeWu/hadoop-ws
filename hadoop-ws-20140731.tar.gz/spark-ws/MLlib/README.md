数据与预处理不区分单双月,数据分析时使用相应单双月查询语句

userinfo-mining/			数据分析时使用查询语句
old.userinfo-mining-m1m2-kmeans/	原来分当双月的脚本

===================
参考:
1. 数据预处理	~/workspace_github/hadoop-ws/hive-ws/MLlib/userinfo-preprocess-onebigdata/

