Spark Softmax

	http://blog.csdn.net/liangliang8086/article/details/17384785

