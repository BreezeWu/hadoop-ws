export VAR_SCP=mahout
/home/hadoop/workspace_github/hadoop-ws/scp-ws/myshell-scp.sh

export VAR_SCP=java_cp
/home/hadoop/workspace_github/hadoop-ws/scp-ws/myshell-scp.sh

export VAR_SCP=scala
/home/hadoop/workspace_github/hadoop-ws/scp-ws/myshell-scp.sh

export VAR_SCP=spark
/home/hadoop/workspace_github/hadoop-ws/scp-ws/myshell-scp.sh

export VAR_SCP=zookeeper
/home/hadoop/workspace_github/hadoop-ws/scp-ws/myshell-scp.sh
export VAR_SCP=不存在的VAR_SCP变量
