object Hi {
  def main(args: Array[String]) = println("Hi!")
}
