jps | kill -9
